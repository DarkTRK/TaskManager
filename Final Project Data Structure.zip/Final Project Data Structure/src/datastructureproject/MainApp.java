package datastructureproject;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MainApp {
    private TaskManager manager = new TaskManager();
    private DefaultListModel<Task> listModel = new DefaultListModel<>();
    private JList<Task> taskListUI = new JList<>(listModel);

    // Color Palette
    private final Color CYBER_BLUE = new Color(0, 168, 232);
    private final Color DEEP_NAVY = new Color(0, 18, 32);
    private final Color NEON_YELLOW = new Color(255, 215, 0);

    public MainApp() {
        JFrame frame = new JFrame("The C List");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(850, 600);
        frame.getContentPane().setBackground(DEEP_NAVY);
        frame.setLayout(new BorderLayout(15, 15));

        // TITLE
        JLabel lblTitle = new JLabel("Epyon Task List", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 30));
        lblTitle.setForeground(NEON_YELLOW);
        lblTitle.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        frame.add(lblTitle, BorderLayout.NORTH);

        // TASK LIST
        taskListUI.setBackground(new Color(0, 27, 46));
        taskListUI.setForeground(Color.WHITE);
        taskListUI.setFont(new Font("Monospaced", Font.BOLD, 14));
        taskListUI.setSelectionBackground(CYBER_BLUE);
        JScrollPane scrollPane = new JScrollPane(taskListUI);
        scrollPane.setBorder(BorderFactory.createLineBorder(CYBER_BLUE, 2));
        frame.add(scrollPane, BorderLayout.CENTER);

        // INPUT PANEL
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        inputPanel.setBackground(DEEP_NAVY);

        JTextField txtId = new JTextField(3);
        JTextField txtTitle = new JTextField(12);
        JComboBox<Task.Priority> comboPriority = new JComboBox<>(Task.Priority.values());

        JButton btnAdd = new JButton("ADD TASK");
        styleButton(btnAdd, CYBER_BLUE, Color.WHITE);

        btnAdd.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText());
                manager.addTask(new Task(id, txtTitle.getText(), (Task.Priority)comboPriority.getSelectedItem()));
                refresh();
                txtId.setText(""); txtTitle.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid ID and Title.");
            }
        });

        inputPanel.add(createLabel("ID:")); inputPanel.add(txtId);
        inputPanel.add(createLabel("Title:")); inputPanel.add(txtTitle);
        inputPanel.add(comboPriority);
        inputPanel.add(btnAdd);

        // ACTION PANEL
        JPanel actionPanel = new JPanel(new FlowLayout());
        actionPanel.setBackground(DEEP_NAVY);

        JButton btnComplete = new JButton("COMPLETE TASK");
        styleButton(btnComplete, NEON_YELLOW, DEEP_NAVY);
        btnComplete.addActionListener(e -> {
            Task selected = taskListUI.getSelectedValue();
            if (selected != null) {
                manager.completeTask(selected.getId());
                refresh();
            }
        });

        JButton btnUndo = new JButton("UNDO (STACK)");
        styleButton(btnUndo, Color.GRAY, Color.WHITE);
        btnUndo.addActionListener(e -> {
            manager.undo();
            refresh();
        });

        actionPanel.add(btnComplete);
        actionPanel.add(btnUndo);

        // Bottom Layout
        JPanel bottomPanel = new JPanel(new GridLayout(2, 1));
        bottomPanel.add(inputPanel);
        bottomPanel.add(actionPanel);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void styleButton(JButton b, Color bg, Color fg) {
        b.setBackground(bg); b.setForeground(fg);
        b.setFocusPainted(false); b.setFont(new Font("Segoe UI", Font.BOLD, 12));
    }

    private JLabel createLabel(String text) {
        JLabel l = new JLabel(text); l.setForeground(Color.WHITE); return l;
    }

    private void refresh() {
        listModel.clear();
        for (Task t : manager.getTasks()) listModel.addElement(t);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainApp::new);
    }
}
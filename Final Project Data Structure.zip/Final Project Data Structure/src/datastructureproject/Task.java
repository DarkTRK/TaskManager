package datastructureproject;
public class Task {
    public enum Priority { HIGH, MEDIUM, LOW }
    public enum Status { PENDING, COMPLETED }

    private int id;
    private String title;
    private Priority priority;
    private Status status;

    public Task(int id, String title, Priority priority) {
        this.id = id;
        this.title = title;
        this.priority = priority;
        this.status = Status.PENDING;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public Priority getPriority() { return priority; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("[%d] %-15s | Priority: %-6s | Status: %s",
                id, title, priority, status);
    }
}
// TaskManager.java
// Author: Zaniel Cruz, Danny Quinones
//﻿ Date: 2026-05-15
// Class: COMP 2900 Data Structures
// Description: The TaskManager class serves as a central controller for managing the lifecycle of Task objects.
package datastructureproject;

import java.util.*;

public class TaskManager {

    private List<Task> taskList = new ArrayList<>();        // For the main list
    private Map<Integer, Task> taskMap = new HashMap<>();    // For fast ID searching
    private Stack<Task> undoStack = new Stack<>();           // For the Undo feature
    private Queue<Task> pendingQueue = new LinkedList<>();    // For FIFO processing

    public void addTask(Task t) {
        taskList.add(t);
        taskMap.put(t.getId(), t);
        pendingQueue.add(t);
    }

    public void completeTask(int id) {
        Task t = taskMap.get(id);
        if (t != null) {
            t.setStatus(Task.Status.COMPLETED);
            undoStack.push(t);
        }
    }

    public void undo() {
        if (!undoStack.isEmpty()) {
            Task t = undoStack.pop();
            t.setStatus(Task.Status.PENDING);
        }
    }

    public List<Task> getTasks() {
        return taskList;
    }
}